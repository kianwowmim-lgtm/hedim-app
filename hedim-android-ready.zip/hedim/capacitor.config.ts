import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hedim.app',
  appName: 'هدیم',
  webDir: '.',
  bundledWebRuntime: false
};

export default config;

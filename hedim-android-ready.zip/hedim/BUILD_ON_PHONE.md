# ساخت APK هدیم بدون کامپیوتر

1. این پروژه را در یک مخزن GitHub قرار دهید.
2. به تب Actions بروید.
3. workflow با نام Build Hedim APK را اجرا کنید.
4. پس از پایان موفق، artifact با نام hedim-apk را دانلود کنید.
5. فایل app-debug.apk را روی گوشی نصب کنید.
